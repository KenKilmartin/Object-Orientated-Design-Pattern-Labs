public interface CommandHolder {
   public void setCommand(Command comd);
   public Command getCommand();
}
